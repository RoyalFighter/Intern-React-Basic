Used concept in react
useReducer hook for state management like fetch sucess add update and delete(CURD)
useContext for dummy user context creation to further use concept of protected route;
customHook to  toogle between light and drk mode in app.
useeffect hook for showing different conditiion where comp renders
meme comp just to fetch api and get vlaue form input feild and display on Ui
